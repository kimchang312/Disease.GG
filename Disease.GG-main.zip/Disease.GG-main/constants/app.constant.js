require('dotenv').config();

const SERVER_PORT = process.env.SERVER_PORT;

module.exports = { SERVER_PORT };
